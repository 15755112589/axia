# * coding :utf_8 *
# author : '阿虾'

#登录成功
success_data = {'user':'15755112589', 'passwd': 'wykdx2011'}

#用户名为空
no_user = {'user':'','passwd':'wykdx2011'}

#用户名格式输入错误
wrong_username = {'user':'1575511','passwd':'wykdx2011'}

#密码为空
no_passwd = {'user':'15755112589','passwd':''}

#用户名未注册
no_register = [{'user':'157','passwd':'wykdx2011'},
                {'user':'15711111111','passwd':'123465567'}]

#密码格式输入错误
wrong_passwd = [{'user':'15755112589','passwd':'1234'},
                {'user':'15755112589','passwd':'12345678912345678'}]

