# * coding :utf_8 *
# author : '阿虾'
import pytest
import time
import unittest
from selenium import webdriver
from appium.webdriver.common.mobileby import MobileBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from PageObjects.loginpage import LoginPage
from PageObjects.indexpage import IndexPage
from CommonFile.set_button import SetButton

@pytest.mark.usefixtures('index_app')
#@pytest.mark.smoke
class TestIndex():

    #@pytest.mark.smoke
    #1、切换设备
    def test_switch_devices(self, index_app):
        IndexPage(index_app).switch_devices()
        assert IndexPage(index_app).get_voice_wake() == '声控唤醒'
        assert IndexPage(index_app).get_grow_up() == '成长计划'

    #@pytest.mark.smoke
    #2、灯光开关:801
    def test_switch_light(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("灯光开关")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(801).get_button_status()
        IndexPage(index_app).set_light()
        time.sleep(2)
        last_status = SetButton(801).get_button_status()
        assert current_status != last_status

    #3、儿童锁:701
    def test_kid_lock(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("儿童锁")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(701).get_button_status()
        IndexPage(index_app).set_kid_lock()
        time.sleep(2)
        last_status = SetButton(701).get_button_status()
        assert current_status != last_status

    #4、自动播消息:1201
    def test_auto_play_msg(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("自动播消息")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(1201).get_button_status()
        IndexPage(index_app).set_auto_play()
        time.sleep(2)
        IndexPage(index_app).get_remind()
        last_status = SetButton(1201).get_button_status()
        assert current_status != last_status

    #5、记忆点播:108
    def test_remember_play(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("记忆点播")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(108).get_math_assistant_status(0)
        IndexPage(index_app).set_remember_play()
        time.sleep(2)
        IndexPage(index_app).get_remind()
        last_status = SetButton(108).get_math_assistant_status(0)
        assert current_status != last_status

    #6、声控唤醒：901
    def test_voice_wake(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("声控唤醒")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(901).get_button_status()
        IndexPage(index_app).set_voice_wake()
        time.sleep(2)
        last_status = SetButton(901).get_button_status()
        assert current_status != last_status

    #7、算术助手:201
    def test_math_assistant(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("算术助手")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        current_status = SetButton(201).get_math_assistant_status(1)
        IndexPage(index_app).set_math_assistant()
        time.sleep(2)
        IndexPage(index_app).get_remind()
        last_status = SetButton(201).get_math_assistant_status(1)
        assert current_status != last_status

    #8、增加定时提醒
    def test_timing_remind(self,index_app):
        IndexPage(index_app).switch_devices()
        current_status = SetButton(401).get_timing_remind()
        IndexPage(index_app).add_reminds()
        last_status = SetButton(401).get_timing_remind()
        assert current_status != last_status

    #9、删除定时提醒
    def test_del_timing_remind(self,index_app):
        IndexPage(index_app).switch_devices()
        current_status = SetButton(401).get_timing_remind()
        IndexPage(index_app).del_remind()
        last_status = SetButton(401).get_timing_remind()
        assert current_status != last_status

    #@pytest.mark.smoke
    #10、设置成长计划自动播放
    def test_grow_plan_auto_play(self,index_app):
        IndexPage(index_app).switch_devices()
        current_status = SetButton(1502).get_button_status()
        IndexPage(index_app).set_grow_plan_auto_play()
        last_status = SetButton(1502).get_button_status()
        assert current_status != last_status

    #11、添加成长计划 ------ 一天一课
    def test_add_grow_plan_1(self,index_app):
        IndexPage(index_app).switch_devices()
        IndexPage(index_app).add_grow_up_plan()
        IndexPage(index_app).swipe_task('诗词', '唐诗三百首')
        IndexPage(index_app).add_task_1()


    @pytest.mark.smoke
    #sum:冒烟功能测试
    def test_smoke(self,index_app):
        IndexPage(index_app).switch_devices()
        locator = 'new UiSelector().text("声控唤醒")'
        WebDriverWait(index_app,30).until(EC.visibility_of_element_located((MobileBy.ANDROID_UIAUTOMATOR,locator)))
        #灯光状态
        current_light_status = SetButton(801).get_button_status()
        IndexPage(index_app).set_light()
        #time.sleep(1)
        last_light_status = SetButton(801).get_button_status()

        #童锁状态
        current__lock_status = SetButton(701).get_button_status()
        IndexPage(index_app).set_kid_lock()
        last_lock_status = SetButton(701).get_button_status()

        #自动播放
        current_auto_play_status = SetButton(1201).get_button_status()
        IndexPage(index_app).set_auto_play()
        IndexPage(index_app).get_remind()
        last_auto_play_status = SetButton(1201).get_button_status()

        #记忆点播
        current_remember_play_status = SetButton(108).get_math_assistant_status(0)
        IndexPage(index_app).set_remember_play()
        IndexPage(index_app).get_remind()
        last_remember_play_status = SetButton(108).get_math_assistant_status(0)

        #声控唤醒
        current_voice_wake_status = SetButton(901).get_button_status()
        IndexPage(index_app).set_voice_wake()
        time.sleep(1)
        last_voice_wake_status = SetButton(901).get_button_status()

        #算术助手
        current_math_assistant_status = SetButton(201).get_math_assistant_status(1)
        IndexPage(index_app).set_math_assistant()
        #time.sleep(1)
        IndexPage(index_app).get_remind()
        last_math_assistant_status = SetButton(201).get_math_assistant_status(1)

        #添加提醒
        current_remind_status = SetButton(401).get_timing_remind()
        IndexPage(index_app).add_reminds()
        last_remind_status = SetButton(401).get_timing_remind()

        #删除提醒
        current_del_remind_status = SetButton(401).get_timing_remind()
        IndexPage(index_app).del_remind()
        last_del_remind_status = SetButton(401).get_timing_remind()

        #设置成长计划自动播放
        current_plan_auto_play = SetButton(1502).get_button_status()
        IndexPage(index_app).set_grow_plan_auto_play()
        last_plan_auto_play = SetButton(1502).get_button_status()

        assert current__lock_status != last_lock_status
        assert current_auto_play_status != last_auto_play_status
        assert current_light_status != last_light_status
        assert current_math_assistant_status != last_math_assistant_status
        assert current_remember_play_status != last_remember_play_status
        assert current_voice_wake_status != last_voice_wake_status
        assert current_remind_status != last_remind_status
        assert current_del_remind_status != last_del_remind_status
        assert current_plan_auto_play != last_plan_auto_play