# * coding :utf_8 *
# author : '阿虾'

#----操作无界面chrome浏览器----
import pytest
from TestDatas import LoginData as LD
from PageObjects.loginpage import LoginPage
from PageObjects.indexpage import IndexPage

@pytest.mark.usefixtures("login_app")
class TestLogin:

    #@pytest.mark.smoke
    #登录成功
    def test_login_app_success(self,login_app):
        LoginPage(login_app).login(LD.success_data['user'],LD.success_data['passwd'])
        assert IndexPage(login_app).get_voice_setting() == '音量调整'

    # @pytest.mark.usefixtures("login_app")
    #@pytest.mark.smoke
    #用户名为空
    def test_login_noUsername(self,login_app):
        LoginPage(login_app).login(LD.no_user['user'],LD.no_user['passwd'])
        assert LoginPage(login_app).no_input_username() == '手机号/邮箱号 不能为空'

    # @pytest.mark.usefixtures("login_app")
    # @pytest.mark.smoke
    #用户名格式错误
    def test_login_wrongUsername(self,login_app):
        LoginPage(login_app).login(LD.wrong_username['user'],LD.wrong_username['passwd'])
        assert LoginPage(login_app).phone_no_register() == '手机号/邮箱号 未注册'

    # @pytest.mark.usefixtures("login_app")
    # @pytest.mark.smoke
    #密码为空
    def test_login_noPasswd(self,login_app):
        LoginPage(login_app).login(LD.no_passwd['user'],LD.no_passwd['passwd'])
        assert LoginPage(login_app).no_input_passwd() == '密码不能为空'

    # @pytest.mark.usefixtures("login_app")
    # @pytest.mark.smoke
    #密码输入错误
    def test_login_wrongPasswd(self,login_app):
        LoginPage(login_app).login(LD.wrong_passwd[0]['user'],LD.wrong_passwd[0]['passwd'])
        #找到账号或密码错误的提示
        assert LoginPage(login_app).wrong_passwd_input() == '密码格式不正确'
