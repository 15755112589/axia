# * coding :utf_8 *
# author : '阿虾'
import logging
import time
import datetime
from logging.handlers import RotatingFileHandler
from CommonFile import dir_config
import os

formatter = " %(asctime)s-%(levelname)s-%(filename)s-%(funcName)s-日志信息:%(message)s"
datefat = '%a %d %b %Y %H:%M:%S'

handle_1 = logging.StreamHandler()

curTime = time.strftime('%Y_%m_%d %H-%M-%S', time.localtime())

handle_2 = RotatingFileHandler(dir_config.logfile_path + '/log_{0}.log'.format(curTime), backupCount=20, encoding='utf-8')

#设置rootlogger的输出内容形式，输出渠道
logging.basicConfig(format=formatter,datefmt=datefat,level=logging.INFO, handlers=[handle_1, handle_2])

#logging.info('测试一下')