# * coding :utf_8 *
# author : '阿虾'

import pytest
import time

curTime = time.strftime('%Y-%m-%d %H-%M-%S')

pytest.main(['-m','smoke',
             '--reruns','1',
             "--html=HtmlTestReport\\toycloud_test_report_{0}.html".format(curTime)])
