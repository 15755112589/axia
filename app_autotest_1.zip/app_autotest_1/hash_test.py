# * coding :utf_8 *
# author : '阿虾'

from urllib import request
from urllib import parse
import urllib
url_1 = 'http://tcapi.xf-yun.com/task/get_task_list'
url = {'device_id':'105130AEA45EEE54','start_time':'2018-11-20 00:00:00','end_time':'2018-11-21 00:00:00'}

url_code = urllib.parse.urlencode(url)
print(url_code)













import hashlib

# parent_token_seed = "fvKs2s93SA0di1AaK"
# token = 'e02c1adf1b0f5dc56e02b6e0716d0d5cdaea4616'
#hash_token = '8c48007e07feb662b62cdc8e643a2ba0a67cd1df'

# password_1 = '4dc4c636667fbd6b00eef4dbe4063667d9765b4a'
# password = 'wykdx2011'
# password_seed0 = "mkOkd9e10sdEwSA0s1234567"
# password_seed1 = "DkS911QpsAkS0J1tU"
# password_seed2 = "Ml2Wkd09L1kDla81Q"

# s = hashlib.sha1()
# s.update((parent_token_seed + token).encode('utf-8'))
# hash_token = s.hexdigest()
# print(hash_token)



# s = hashlib.sha1()
# s.update((password_seed1 + password).encode('utf-8'))
# print(s.hexdigest())