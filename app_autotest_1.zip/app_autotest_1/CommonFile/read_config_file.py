# * coding :utf_8 *
# author : '阿虾'

#读取配置文件中的数据
import configparser
from CommonFile import dir_config

class ReadConfigFile():

    def read_config_file(self, file_name, section_name, option_name):
        configfile = configparser.ConfigParser()
        #读取文件
        configfile.read(file_name, encoding='utf-8')
        value = configfile.get(section_name, option_name)
        return value

if __name__ == '__main__':
    res = ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'SET_DATA', 'set_data')
    print(res)