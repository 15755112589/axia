# * coding :utf_8 *
# author : '阿虾'

import os
#获取根目录
base_dir = os.path.split(os.path.split(os.path.realpath(__file__))[0])[0]
#print(base_dir)

#日志文件存放路径
logfile_path = os.path.join(base_dir,"LogFiles")
# print(logfile_path)

#屏幕截图存放路径
Screen_shot_path = os.path.join(base_dir,"ScreenShot")
#print(Screen_shot_path)

#测试报告存放地址
htmltestreport_path = os.path.join(base_dir,'HtmlTestReport')
# print(htmltestreport_path)

#yaml文件路径
caps_yaml_path = os.path.join(base_dir,'Caps_ConfigFile','caps.yaml')
#print(caps_yaml_path)

#接口数据配置文件路径
data_config_file_path = os.path.join(base_dir,'Caps_ConfigFile','data_config.conf')
#print(data_config_file_path)
