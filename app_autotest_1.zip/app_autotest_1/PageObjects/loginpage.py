# * coding :utf_8 *
# author : '阿虾'

from appium.webdriver.common.mobileby import MobileBy
from CommonFile.basepage import BasePage

class LoginPage(BasePage):

    #登录按钮
    login_button = 'com.iflytek.hi_panda_parent:id/btn_login'
    #用户名输入框
    username_input = 'com.iflytek.hi_panda_parent:id/et_phone'
    #密码输入框
    passwd_input = 'com.iflytek.hi_panda_parent:id/et_password'
    #确定按钮
    sure_button = 'com.iflytek.hi_panda_parent:id/tv_toolbar_end'
    #手机号/邮箱号不能为空提示
    no_user_passwd = '手机号/邮箱号 不能为空'
    #密码不能为空
    no_passwd = '密码不能为空'
    #密码格式不正确
    wrong_passwd = '密码格式不正确'
    #用户名或密码错误
    wrong_user_passwd = '用户名或密码错误'
    #手机号/邮箱号 未注册
    no_register = '手机号/邮箱号 未注册'
    #我的按钮
    setting = 'com.iflytek.hi_panda_parent:id/tv_setting'
    #用户头像
    user_image = 'com.iflytek.hi_panda_parent:id/iv_user_icon'
    #退出登录按钮
    exit_button = 'com.iflytek.hi_panda_parent:id/tv_item_operation'
    #确定退出按钮
    exit_sure = 'com.iflytek.hi_panda_parent:id/btn_positive'


    #登录成功
    def login(self,user,passwd):
        name = '登录界面_登录操作'
        self.wait_eleVisible(self.login_button,model=name)
        self.click_ele(self.login_button,model=name)
        self.wait_eleVisible(self.username_input,model=name)
        self.clear_content(self.username_input,model=name)
        self.input_text(user,self.username_input,model=name)
        self.input_text(passwd,self.passwd_input,model=name)
        self.click_ele(self.sure_button,model=name)

    #退出登录
    def exit_login(self):
        name = '退出登录'
        self.click_ele(self.setting,model=name)
        self.wait_eleVisible(self.user_image,model=name)
        self.click_ele(self.user_image,model=name)
        self.wait_eleVisible(self.exit_button,model=name)
        self.click_ele(self.exit_button,model=name)
        self.click_ele(self.exit_sure,model=name)

    #未输入密码
    def no_input_passwd(self):
        name = '登录界面_未输入号码'
        locator = 'new UiSelector().text("{0}")'.format(self.no_passwd)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #用户名为空
    def no_input_username(self):
        name = '登录界面_未输入用户名'
        locator = 'new UiSelector().text("{0}")'.format(self.no_user_passwd)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #密码格式不正确（少于6位数）
    def wrong_passwd_input(self):
        name = '登录界面_输入格式错误的密码'
        locator = 'new UiSelector().text("{0}")'.format(self.wrong_passwd)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #手机号/邮箱号未注册
    def phone_no_register(self):
        name = '登录界面_手机号未注册'
        locator = 'new UiSelector().text("{0}")'.format(self.no_register)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #用户名或密码错误（输入错误的密码）
    def wrong_user_or_passwd(self):
        name = '登录界面_用户名或密码错误'
        locator = 'new UiSelector().text("{0}")'.format(self.wrong_user_passwd)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)