# * coding :utf_8 *
# author : '阿虾'

import yaml

fs = open("caps.yaml")
python_obj = yaml.load(fs)
print(python_obj)