# * coding :utf_8 *
# author : '阿虾'


#定义一个函数，实现用例的准备和清理工作
#在函数前面加上@pytest.fixture
#fixture可以设置作用域范围

import pytest
from appium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from appium.webdriver.common.mobileby import MobileBy
from PageObjects.loginpage import LoginPage
from TestDatas import LoginData as LD
from CommonFile import dir_config
import yaml

@pytest.fixture
def login_app():
    desired_caps = get_desired_caps()
    driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps)
    yield driver
    driver.close_app()
    driver.quit()

@pytest.fixture
def index_app():
    desired_caps = get_desired_caps()
    driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub',desired_caps)
    WebDriverWait(driver,10).until(EC.visibility_of_element_located((MobileBy.ID,'com.iflytek.hi_panda_parent:id/btn_login')))
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/btn_login').click()
    # LoginPage(driver).login(LD.success_data['user'], LD.success_data['passwd'])
    WebDriverWait(driver,10).until(EC.visibility_of_element_located((MobileBy.ID,'com.iflytek.hi_panda_parent:id/et_phone')))
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/et_phone').clear()
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/et_phone').send_keys('15755112589')
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/et_password').send_keys('wykdx2011')
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/tv_toolbar_end').click()
    yield driver
    #点击设置按钮
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/tv_setting').click()
    #点击用户头像
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/iv_user_icon').click()
    #点击退出登录
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/tv_item_operation').click()
    #点击确定
    driver.find_element_by_id('com.iflytek.hi_panda_parent:id/btn_positive').click()
    driver.quit()

#设置automationName和noReset的值
def get_desired_caps(automationName=None,noReset=False):
    fs = open(dir_config.caps_yaml_path,encoding='utf-8')
    desired_caps = yaml.load(fs)
    if automationName is None:
        desired_caps['automationName'] = automationName
    if noReset == True:
        desired_caps['noReset'] = True
    return desired_caps

