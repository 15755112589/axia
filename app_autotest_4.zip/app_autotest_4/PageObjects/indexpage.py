# * coding :utf_8 *
# author : '阿虾'

import appium
from appium import webdriver
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from CommonFile.basepage import BasePage
from appium.webdriver.common.mobileby import MobileBy

class IndexPage(BasePage):

    #设备名称下拉框
    drop_down_box = 'com.iflytek.hi_panda_parent:id/iv_toolbar_arrow'
    #右上角加号
    plus_symbol = 'com.iflytek.hi_panda_parent:id/iv_toolbar_more'
    #设备按钮
    device = 'com.iflytek.hi_panda_parent:id/tv_device'
    #内容按钮
    content = 'com.iflytek.hi_panda_parent:id/tv_content'
    #语音助手
    assistant = 'com.iflytek.hi_panda_parent:id/tv_assistant'
    #微聊组按钮
    group = 'com.iflytek.hi_panda_parent:id/tv_group'
    #我的按钮
    setting = 'com.iflytek.hi_panda_parent:id/tv_setting'
    #萌宝说说
    cute_baby = '萌宝说说'
    #我的歌单
    my_songs_list = '我的歌单'
    #亲子微聊
    child_chat = '亲子微聊'
    #音量调整
    voice_set = '音量调整'
    #定时提醒
    timing_remind = '提醒'
    locator_remind = 'new UiSelector().textContains("{0}")'.format(timing_remind)
    #添加提醒
    add_remind = 'com.iflytek.hi_panda_parent:id/btn_add_schedule'
    #提醒内容
    remind_content = '提醒内容'
    #输入提醒内容
    input_remind_content = 'com.iflytek.hi_panda_parent:id/et_content'
    #已设置的消息内容
    seted_remind_content = 'com.iflytek.hi_panda_parent:id/tv_item_content'
    #确定按钮
    sure = 'com.iflytek.hi_panda_parent:id/tv_toolbar_end'
    #删除按钮
    delete_button = 'com.iflytek.hi_panda_parent:id/tv_item_operation'
    #提示确定按钮
    make_sure = 'com.iflytek.hi_panda_parent:id/btn_positive'
    #定时关机
    timing_off = '定时关机'
    #灯光开关
    light_set = '灯光开关'
    #儿童锁
    kid_lock = '儿童锁'
    #声控唤醒
    voice_wake = '声控唤醒'
    #自动播消息
    auto_play = '自动播消息'
    #自动播消息打开
    auto_play_open_hint = '微聊组消息自动播放功能—已开启'
    #自动播消息关闭
    auto_play_close_hint = '微聊组消息自动播放功能—已关闭'
    #记忆点播
    remember_play = '记忆点播'
    #记忆点播打开提示
    remember_play_open_hint = '记忆功能已开启，点播内容将根据上次的播放进度续播。'
    #记忆点播关闭提示
    remember_play_close_hint = '记忆功能已关闭，点播内容将重新播放。'
    #算术助手
    math_assistant = '算术助手'
    #算术助手打开提示
    math_assistant_open_hint = '算术助手已开启。每15分钟内设备只回答5道算术题，培养孩子自主思考的好习惯'
    #算术助手关闭提示
    math_assistant_close_hint = '算术助手已关闭'
    #成长计划
    grow_up_plan = '成长计划'
    #成长计划自动播放
    grow_plan_auto_play = 'com.iflytek.hi_panda_parent:id/tv_auto_play'
    #自动播放提示框
    plan_remind = 'com.iflytek.hi_panda_parent:id/ll_dialog'
    #总日程表
    daily_list = 'com.iflytek.hi_panda_parent:id/tv_table'
    #添加成长任务
    add_grow_up = '添加成长任务'
    #加入成长计划按钮
    add_grow_up_button = 'com.iflytek.hi_panda_parent:id/tv_item_add_study_plan'
    #加入成长计划确认按钮
    add_grow_up_confirm = 'com.iflytek.hi_panda_parent:id/btn_confirm'
    #设备名称
    device_name = '吴林俊超能蛋'
    #返回按钮
    back_button = 'com.iflytek.hi_panda_parent:id/iv_toolbar_back'
    #萌宝说说提示
    cute_baby_hint = '您与设备的闲聊记录都会呈现在此'
    #设备播放列表
    play_list = 'com.iflytek.hi_panda_parent:id/iv_item_play_list'
    #播放暂停键
    play_pause = 'com.iflytek.hi_panda_parent:id/iv_item_play_pause'
    #上一曲
    last_song = 'com.iflytek.hi_panda_parent:id/iv_item_pre'
    #下一曲
    next_song = 'com.iflytek.hi_panda_parent:id/iv_item_next'
    #全部循环
    all_circulation = 'com.iflytek.hi_panda_parent:id/iv_item_play_mode'
    #提示
    remind = '提示'

    #获取提示
    def get_remind(self):
        name = '首页_提示'
        locator = 'new UiSelector().text("{0}")'.format(self.remind)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #获取首页的音量调节字符
    def get_voice_setting(self):
        name = '首页_获取音量调整元素'
        locator = 'new UiSelector().text("{0}")'.format(self.voice_set)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #获取声控唤醒元素
    def get_voice_wake(self):
        name = '首页_获取声控唤醒元素'
        locator = 'new UiSelector().text("{0}")'.format(self.voice_wake)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #灯光开关
    def set_light(self):
        name = '首页_灯光开关'
        locator = 'new UiSelector().text("{0}")'.format(self.light_set)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #儿童锁
    def set_kid_lock(self):
        name = '首页_儿童锁'
        locator = 'new UiSelector().text("{0}")'.format(self.kid_lock)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #记忆点播
    def set_remember_play(self):
        name = '首页_记忆点播'
        locator = 'new UiSelector().text("{0}")'.format(self.remember_play)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #记忆点播打开提示
    def remember_play_open(self):
        name = '首页_记忆点播打开'
        locator = 'new UiSelector().textContain("{0}")'.format(self.remember_play_open_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #记忆点播关闭提示
    def remember_play_close(self):
        name = '首页_记忆点播关闭'
        locator = 'new UiSelector().textContain("{0}")'.format(self.remember_play_close_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #自动播消息
    def set_auto_play(self):
        name = '首页_自动播消息'
        locator = 'new UiSelector().text("{0}")'.format(self.auto_play)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #自动播消息打开提示
    def auto_play_open(self):
        name = '首页_自动播消息打开提示'
        locator = 'new UiSelector().text("{0}")'.format(self.auto_play_open_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #自动播消息关闭提示
    def auto_play_close(self):
        name = '首页_自动播消息关闭提示'
        locator = 'new UiSelector().text("{0}")'.format(self.auto_play_close_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #声控唤醒
    def set_voice_wake(self):
        name = '首页_声控唤醒'
        locator = 'new UiSelector().text("{0}")'.format(self.voice_wake)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #算术助手
    def set_math_assistant(self):
        name = '首页_算术助手'
        locator = 'new UiSelector().text("{0}")'.format(self.math_assistant)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #打开算术助手
    def get_open_math_assistant(self):
        name = '首页_算术助手打开'
        locator = 'new UiSelector().test("{0}")'.format(self.math_assistant_open_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #关闭算术助手
    def close_math_assistant(self):
        name = '首页_关闭算术助手'
        locator = 'new UiSelector().test("{0}")'.format(self.math_assistant_close_hint)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

    #切换设备
    def switch_devices(self):
        name = '首页_切换设备'
        locator = 'new UiSelector().text("{0}")'.format(self.device_name)
        self.wait_eleVisible(self.drop_down_box,model=name)
        self.click_ele(self.drop_down_box,model=name)
        self.scroll_element(locator,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #获取成长计划元素
    def get_grow_up(self):
        name = '首页_获取成长计划元素'
        locator = 'new UiSelector().text("{0}")'.format(self.grow_up_plan)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return self.get_text(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #成长计划
    def set_grow_up_plan(self):
        name = '首页_设置成长计划'
        locator = 'new UiSelector().text("{0}")'.format(self.grow_up_plan)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #设置成长计划自动播放
    def set_grow_plan_auto_play(self):
        name='成长计划_设置成长计划自动播放'
        self.set_grow_up_plan()
        self.wait_eleVisible(self.daily_list,model=name)
        self.click_ele(self.grow_plan_auto_play,model=name)
        self.wait_eleVisible(self.plan_remind,model=name)
        self.click_ele(self.plan_remind,model=name)
        self.click_ele(self.back_button,model=name)

    #添加学习成长计划
    def add_grow_up_plan(self):
        name = '首页_增加成长计划'
        self.set_grow_up_plan()
        locator = 'new UiSelector().text("{0}")'.format(self.add_grow_up)
        self.scroll_element(locator,model=name)           #定位、点击添加成长计划的按钮
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #滑动任务类型栏，定位任务类型，
    def swipe_add_task(self,task_list,task):
        name = '添加成长计划_选择任务类型'
        locator = 'new UiSelector().text("英语")'
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        locator_list = 'new UiSelector().text("{0}")'.format(task_list)
        self.swipe_ele_to_click(locator_list,model=name)       #滑动并点击任务类型
        locator_task = 'new UiSelector().text("{0}")'.format(task)
        self.click_ele(locator_task,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)    #点击学习任务名称
        self.wait_eleVisible(self.add_grow_up_button,model=name)
        self.click_ele(self.add_grow_up_button,model=name)       #点击加入成长计划
        self.wait_eleVisible(self.add_grow_up_confirm,model=name)
        self.click_ele(self.add_grow_up_confirm,model=name)  #点击专辑底部确认加入成长计划按钮
        self.wait_eleVisible(self.grow_plan_auto_play, model=name)  #等到出现自动播放的按钮
        self.click_ele(self.back_button,model=name)  #点击返回按钮，回到设备页

    '''
    #查找刚刚添加的任务，判断是否添加成功
    def sure_add(self,task):
        name = '成长计划_确认添加成功'
        self.wait_eleVisible(self.grow_plan_auto_play,model=name)
        locator = 'new UiSelector().text("{0}")'.format(task)
        ele = self.find_element(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        return ele.text

     #退出成长计划 ------  一天一课
    def exit_task(self):
        name = '加入成长计划_一天一课'
        self.click_ele(self.back_button,model=name)  #点击返回按钮，回到设备页

    '''

    #开始任务
    def start_task(self,task):
        name = '成长计划_开始任务'
        self.wait_eleVisible(self.grow_plan_auto_play,model=name)
        locator = 'new UiSelector().text("{0}")'.format(task)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        locator_start = 'new UiSelector().text("开始任务")'
        self.wait_eleVisible(locator_start,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator_start,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(self.back_button,model=name)

    #删除成长计划中的任务
    def del_grow_plan(self,task):
        name = '成长计划_删除任务'
        self.wait_eleVisible(self.grow_plan_auto_play,model=name)
        locator = 'new UiSelector().text("{0}")'.format(task)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        locator_del = 'new UiSelector().text("删除任务")'
        self.wait_eleVisible(locator_del,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator_del,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(self.make_sure,model=name)
        self.click_ele(self.back_button,model=name)

    #点击萌宝说说
    def enter_cute_baby(self):
        name = '首页_进入萌宝说说'
        locator = 'new UiSelector().text("{0}")'.format(self.cute_baby)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #退出萌宝说说
    def exit_cute_baby(self):
        name = '退出萌宝说说'
        locator = 'new UiSelector().text("{0}")'.format(self.cute_baby_hint)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(self.back_button,model=name)

    #切换算术助手
    def switch_math_assistant(self):
        name = '首页_切换算术助手'
        locator = 'new UiSelector().text("{0}")'.format(self.math_assistant)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)

    #添加定时提醒
    def add_reminds(self):
        name = '首页_添加定时提醒'
        locator_remind = 'new UiSelector().textContains("{0}")'.format(self.timing_remind)
        self.wait_eleVisible(locator_remind,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator_remind,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        #添加提醒按钮
        self.wait_eleVisible(self.add_remind,model=name)
        self.click_ele(self.add_remind,model=name)
        #提醒内容
        content_locator = 'new UiSelector().text("{0}")'.format(self.remind_content)
        self.wait_eleVisible(content_locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(content_locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        #点击提醒内容进行添加
        self.wait_eleVisible(self.input_remind_content,model=name)
        self.click_ele(self.input_remind_content,model=name)
        #输入提醒内容
        self.input_text('123456789',self.input_remind_content,model=name)
        #点击确定
        self.click_ele(self.sure,model=name)
        self.wait_eleVisible(self.sure,model=name)
        #点击确定
        self.click_ele(self.sure,model=name)
        self.wait_eleVisible(self.back_button,model=name)
        #点击返回按钮
        self.click_ele(self.back_button,model=name)

    #删除定时提醒
    def del_remind(self):
        name = '删除定时提醒'
        locator = 'new UiSelector().textContains("{0}")'.format(self.timing_remind)
        self.wait_eleVisible(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model=name)
        #点击单条提醒
        self.wait_eleVisible(self.seted_remind_content,model=name)
        self.click_ele(self.seted_remind_content,model=name)
        #点击删除
        self.wait_eleVisible(self.delete_button,model=name)
        self.click_ele(self.delete_button,model=name)
        #点击确定
        self.wait_eleVisible(self.make_sure,model=name)
        self.click_ele(self.make_sure,model=name)
        #点击返回
        self.click_ele(self.back_button)
