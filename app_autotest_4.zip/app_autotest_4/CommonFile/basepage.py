# * coding :utf_8 *
# author : '阿虾'
import appium
import requests
import json
from appium import webdriver
from appium.webdriver.common.mobileby import MobileBy
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import datetime
from CommonFile.read_config_file import ReadConfigFile
from CommonFile import logger
import logging
from CommonFile import dir_config
import time

class BasePage():

    def __init__(self,driver):
        self.driver = driver

    #等待元素可见
    def wait_eleVisible(self,locator,by=MobileBy.ID,model='model',wait_time=100,requence=0.5):
        try:
            start = datetime.datetime.now()
            WebDriverWait(self.driver,wait_time,requence).until(EC.visibility_of_element_located((by,locator)))
            end = datetime.datetime.now()
            wait_times = (end - start).seconds
            logging.info('等待元素可见时长为：{0}'.format(wait_times))
        except Exception as e:
            logging.exception('等待元素可见异常')
            self._save_screenShot(model)
            raise e

    #等待元素存在
    def wait_elePresence(self,locator, by=MobileBy.ID,model='model',wait_time=100,requence=0.1):
        try:
            start = datetime.datetime.now()
            WebDriverWait(self.driver,wait_time,requence).until(EC.presence_of_element_located((by,locator)))
            end = datetime.datetime.now()
            wait_times = (end - start).seconds
            logging.info('等待元素存在时长为：{0}'.format(wait_times))
        except:
            logging.exception('等待元素存在异常')
            self._save_screenShot(model)
            raise

    #查找单个元素
    def find_element(self,locator,by=MobileBy.ID,model='model'):
        logging.info('开始查找元素：{0}={1}'.format(by,locator))
        try:
            return self.driver.find_element(by,locator)
        except:
            logging.exception('查找元素失败')
            self._save_screenShot(model)
            raise

    #查找多个元素
    def find_elements(self,locator,by=MobileBy.ID,model='model'):
        logging.info('开始查找符合表达式的所有元素：{0}={1}'.format(by,locator))
        try:
            self.find_elements(locator,by)
        except:
            logging.exception('查找元素失败')
            self._save_screenShot(model)
            raise

    #清理输入框中的内容
    def clear_content(self,locator,by=MobileBy.ID,model='model'):
        logging.info('开始清理输入框：{0}={1}'.format(by,locator))
        ele = self.find_element(locator,by,model)
        try:
            ele.clear()
        except:
            logging.exception('清理输入框失败')
            self._save_screenShot(model)
            raise


    #保存屏幕截图
    def _save_screenShot(self,model_name='model'):
        #根据功能和时间点生成截图
        # 文件格式：功能名称+年-月-日 时-分-秒.png
        curTime = time.strftime('%Y_%m_%d %H-%M-%S', time.localtime())
        #截图存放路径
        file_path = (dir_config.Screen_shot_path+"/{0}_{1}.png".format(model_name,curTime))
        #driver方法：self.driver.save_screenshot()
        self.driver.save_screenshot(file_path)
        logging.info('截图成功，路径为：{0}'.format(file_path))

    #在查找的多个元素中选择一个元素
    def select_ele_from_eles(self,locator,by=MobileBy.ID,model='model',index=None):
        import random
        eles = self.find_elements(locator,by)
        if index == -1 or index < 0:
            pos = random.randint(0,len(eles)-1)
            return eles[pos]
        else:
            return eles[index]

    #确定要操作的元素----查找多个或是查找单个元素，确定元素操作对象
    def get_element(self,locator,by=MobileBy.ID,model='model',index=None):
        #若index不为None时，为查找多个元素，从多个元素中选一个，为None时为查找单个元素
        if index is not None:
            #在查找的多个元素中选择1个
            return self.select_ele_from_eles(locator,by,model,index)
        else:
            return self.find_element(locator,by,model)

    #执行点击元素操作
    def click_ele(self,locator,by=MobileBy.ID,model='model',index=None):
        logging.info('开始执行点击操作')
        ele = self.get_element(locator,by,model,index)
        try:
            ele.click()
        except:
            logging.exception('执行点击操作失败')
            self._save_screenShot(model)
            raise

    #获取元素文本
    def get_text(self,locator,by=MobileBy.ID,model='model',index=None):
        """
        :param locator: 元素定位的表达式
        :param by:元素定位的类型
        :param model:模块或者用例名称。主要用在截图文件命名中，方便查找和定位。
        :param index:是否要在多个元素中选择一个元素来操作。应用于查找多个元素的基础。
          index=None表示查找一个元素。
          index=-1 表示查找多个元素，并在多个元素中随机选一个；
          index > -1 表示查找多个元素，并且根据index的值取对应下标的元素。
        :return:元素的文本内容。
        """
        logging.info('开始获取元素文本：{0}={1}'.format(by,locator))
        ele = self.get_element(locator,by,model,index)
        try:
            return ele.text
        except:
            logging.exception('获取元素文本失败')
            self._save_screenShot(model)
            raise

    #输入文本
    def input_text(self,value,locator,by=MobileBy.ID,model='model',index=None):
        ele = self.get_element(locator,by,model,index)
        try:
            ele.send_keys(value)
        except:
            logging.exception('输入文本失败')
            self._save_screenShot(model)
            raise

    #获取元素的属性值
    def get_element_attribute(self,attr_name,locator,by=MobileBy.ID,model='model',index=None):
        logging.info('获取元素：{0}={1}的属性值:{3}'.format(locator,by,attr_name))
        ele = self.get_element(locator,by,model,index)
        try:
            return ele.get_attribute(attr_name)
        except:
            logging.exception('{0}下获取元素属性值失败'.format(model))
            self._save_screenShot(model)
            raise

    #元素滚动操作,将元素滚动到可见区域
    def scroll_element(self,locator,by=MobileBy.ANDROID_UIAUTOMATOR,model='model',index=None):
        logging.info('{0}:滚动元素{1}={2}到可见区域'.format(model,by,locator))
        try:
            self.driver.find_element_by_android_uiautomator('new UiScrollable('
                                           'new UiSelector().scrollable(true).instance(0)).'
                                           'scrollIntoView({0}.instance(0))'.format(locator))
        except:
            logging.exception('滚动元素可见失败')
            self._save_screenShot(model)
            raise

    #滑屏操作，滑动屏幕找到相应元素并点击
    def swipe_ele_to_click(self,locator,by=MobileBy.ANDROID_UIAUTOMATOR,model='model'):
        logging.info('获取屏幕的宽高')
        width = self.driver.get_window_size()['width']
        height = self.driver.get_window_size()['height']
        logging.info('{0}:滑动元素{1}={2}到可点击区域'.format(model,by,locator))
        i = 0
        while i < 10:
            try:
                #尝试点击元素
                self.click_ele(locator,by=MobileBy.ANDROID_UIAUTOMATOR,model='model')
                break
            except Exception as e:
                self.driver.swipe(width*0.5, height*0.13, width*0.1, height*0.13)
                i = i + 1
                if i == 10:
                    print('no element')

