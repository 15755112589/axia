# * coding :utf_8 *
# author : '阿虾'

import requests
import json
import datetime
from CommonFile.read_config_file import ReadConfigFile
from CommonFile import dir_config
from CommonFile import logger
import logging
import hashlib
import urllib
from urllib import parse

class SetButton:

    def __init__(self,key):
        self.key = key

    #获取按钮当前状态
    #策略：在点击按钮之前先获取一下按钮的当前状态值，存起来，在进行点击操作之后，再获取一下状态值，两个值做一下对比
    #相等就报错，不相等就通过
    def get_button_status(self):
        #获取按钮状态数据的接口地址
        get_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'GET', 'get_data_attr')
        #获取按钮状态的请求数据
        get_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'GET_DATA', 'get_data'))
        get_data["get_data_list"][0]["key"] = self.key
        new_get_data = get_data
        res_get = requests.post(get_data_attr,json=new_get_data)
        #将json数据转换成python对象
        s = json.loads(res_get.text,encoding='utf-8')
        value = s['data_list'][0]['value']
        return value

    #获取算术助手状态
    def get_math_assistant_status(self,key_number):
        #获取按钮状态数据的接口地址
        get_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'GET_MATH', 'get_data_attr')
        #获取按钮状态的请求数据
        get_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'GET_MATH_DATA', 'get_data'))
        res_get = requests.get(get_data_attr,get_data)
        #将json数据转换成python对象
        s = json.loads(res_get.text,encoding='utf-8')
        #value = s['data_list'][key_number]['value']
        return s

    #获取定时提醒的条数
    #策略：添加或删除定时提醒前，获取一下提醒的条数，添加或删除后再获取一次，对比两次获取的提醒的条数，不同则判断为操作成功
    def get_timing_remind(self):
        #获取定时提醒的地址
        get_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_REMIND','get_data_attr')
        #获取定时提醒的请求数据
        get_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_TIMING_REMIND','get_data'))
        result = requests.post(get_data_attr,json=get_data)
        #将返回的json格式数据转换成python格式
        s = json.loads(result.text,encoding='utf8')
        value = len(s["data_list"][0]["value"])
        return value

    #获取成长计划任务列表
    #策略：添加或删除成长计划任务之前获取一下任务列表，之后在获取一下列表长度，对比两次的长度值是否一致，从而判断是否添加
    #或者删除成功
    def get_grow_plan_list(self):
        get_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_TASK_ATTR','get_data_attr')
        get_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_TASK','get_data'))
        start_time = datetime.date.today()    #设置开始查询的时间为当前日期
        get_data['start_time'] = start_time.strftime('%Y-%m-%d 00:00:00')
        end_time = start_time + datetime.timedelta(days=1)    #设置结束查询的时间为开始时间的后一天
        get_data['end_time'] = end_time.strftime('%Y-%m-%d 00:00:00')
        #对传入的参数进行编码处理
        new_data = urllib.parse.urlencode(get_data)
        headers = {'Content-Type': 'application/x-www-form-urlencoded',
                   'device-type': '0030',
                   'hash-token': self.get_hash_token(),
                   'product-type': '0001'}
        result = requests.get(url=get_data_attr, params=new_data, headers=headers)
        s = json.loads(result.text,encoding='utf8')
        #获取任务列表长度
        value = len(s['daily_list'][0]['task_list'])
        return value

    #获取token
    def get_token(self):
        get_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_TOKEN_ATTR','get_data_attr')
        get_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path,'GET_TOKEN','get_data'))
        headers = {'Content-Type':'application/x-www-form-urlencoded',
                   'device-type':'0030',
                   'hash-token':'03c1e4d4b189c450bde6e304fc2ca4e6e12b0c20',
                   'product-type':'0001'}
        result = requests.post(url=get_data_attr,data=get_data,headers=headers)
        s = json.loads(result.text,encoding='utf8')
        return s['token']

    #计算hash_token
    #通过将token经过哈希加密生成hash_token
    def get_hash_token(self):
        token = self.get_token()
        parent_token_seed = "fvKs2s93SA0di1AaK"
        s = hashlib.sha1()
        s.update((parent_token_seed + token).encode('utf-8'))
        hash_token = s.hexdigest()
        return hash_token

    #设置按钮的状态 （未完成）
    def set_button_status(self):
        #设置按钮状态的接口地址
        set_data_attr = ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'SET', 'set_data_attr')
        #设置按钮状态的请求数据
        set_data = eval(ReadConfigFile().read_config_file(dir_config.data_config_file_path, 'SET_DATA', 'set_data'))
        set_data["set_data_list"][0]['key'] = self.key
        #当获取到的当前值是1时，将状态置0
        if self.get_button_status() == 1:
            set_data["set_data_list"][0]['value'] = 0
        #当获取到的当前值是0时，将状态置1
        elif self.get_button_status() == 0:
            set_data["set_data_list"][0]['value'] = 1
        else:
            logging.exception('按钮状态切换出错')
            print('按钮状态切换出错')
        new_set_data = set_data
        res_set = requests.post(set_data_attr,json=new_set_data)
        #将json数据转换成python对象
        res = json.loads(res_set.text,encoding='utf-8')
        # set_value = s['data_list'][0]['value']
        return res

if __name__ == '__main__':

    obj = SetButton('')
    print(type(obj.get_grow_plan_list()))
    print(obj.get_grow_plan_list())

